using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace VerrosMod
{
	public class VerrosMod : Mod
	{
		public VerrosMod()
		{
			
		}
	}
}