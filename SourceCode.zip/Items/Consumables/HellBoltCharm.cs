﻿using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace VerrosMod.Items.Consumables
{
	class HellboltCharm : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hellbolt Charm");
			Tooltip.SetDefault("Summons Harmless Hellbolt Demon. Hellbolt Demon will drop Frostspark Boots and Lava Waders.");
		}

		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 32;
			item.maxStack = 99;
			item.consumable = true;
			item.useStyle = 4;
			item.useAnimation = 30;
			item.useTime = 30;
		}

		public override bool CanUseItem(Player player)
		{
			return !NPC.AnyNPCs(mod.NPCType("HellboltDemon"));
		}

		public override bool UseItem(Player player)
		{
			NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("HellboltDemon"));
			Main.PlaySound(15, (int)player.position.X, (int)player.position.Y, 1);

			return true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(mod.GetItem("HellboltBoots"));
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
