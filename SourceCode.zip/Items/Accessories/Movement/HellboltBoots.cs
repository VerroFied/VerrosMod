﻿using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace VerrosMod.Items.Accessories.Movement
{
	public class HellboltBoots : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hellbolt Boots");
			Tooltip.SetDefault("Harness power over flight, speed, and fire.");
		}

		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 32;
			item.value = 60000;
			item.rare = 7;
			item.accessory = true;
			item.shoeSlot = 8;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.FrostsparkBoots);
			recipe.AddIngredient(ItemID.LavaWaders);
			recipe.AddTile(TileID.TinkerersWorkbench);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.canRocket = true;
			//player.rocketTime = 1;
			player.rocketBoots = 3;
			//player.rocketTimeMax = 1;
			player.accRunSpeed = 6.75f;
			player.moveSpeed += 0.18f;
			player.iceSkate = true;
			player.waterWalk = true;;
			player.lavaMax += 420;
			player.fireWalk = true;
		}
	}
}
