﻿using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace VerrosMod.NPCs.Enemy
{
	class HellboltDemon :ModNPC
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hellbolt Demon");
		}
		public override void SetDefaults()
		{
			npc.width = 66;
			npc.height = 36;
			npc.damage = 0;
			npc.defense = 0;
			npc.lifeMax = 200;
			//npc.HitSound = 
			//npc.DeathSound =
			npc.value = 0f;
			npc.aiStyle = 44;
			Main.npcFrameCount[npc.type] = 4;
			animationType = NPCID.Slimer;

			npc.boss = false;
		}

		public override void NPCLoot()
		{
			Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.FrostsparkBoots);
			Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.LavaWaders);

		}
	}
}
